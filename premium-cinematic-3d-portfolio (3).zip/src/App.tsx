import React, { useEffect, useState } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import { PortfolioProvider } from './context/PortfolioContext';
import { ThreeCanvas } from './components/ThreeCanvas';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutMe } from './components/AboutMe';
import { Scroll3DSection, CardData } from './components/Scroll3DSection';
import { ServicesWork } from './components/ServicesWork';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { SettingsModal } from './components/SettingsModal';
import { ProjectModal } from './components/ProjectModal';

gsap.registerPlugin(ScrollTrigger);

export const App: React.FC = () => {
  const [selectedCard, setSelectedCard] = useState<CardData | null>(null);

  // Initialize Lenis smooth scroll and connect to GSAP ScrollTrigger
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });

    lenis.on('scroll', ScrollTrigger.update);

    const updateLenis = (time: number) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(updateLenis);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(updateLenis);
      lenis.destroy();
    };
  }, []);

  return (
    <PortfolioProvider>
      <div className="relative min-h-screen bg-[#0A0A0F] text-[#F3F4F6] selection:bg-[#7C3AED] selection:text-white font-inter">
        {/* UI Transparent Background 3D Canvas reacting to mouse and scroll */}
        <ThreeCanvas />

        {/* Foreground Content */}
        <div className="relative z-10">
          <Navbar />

          <main>
            {/* HERO SECTION (Top) */}
            <Hero />

            {/* ABOUT ME SECTION */}
            <AboutMe />

            {/* SCROLL ANIMATION SECTION (GSAP ScrollTrigger + Lenis 3D Cards) */}
            <Scroll3DSection onSelectCard={(card) => setSelectedCard(card)} />

            {/* SERVICES / MY WORK SECTION */}
            <ServicesWork onInspectService={(card) => setSelectedCard(card)} />

            {/* CONTACT SECTION */}
            <ContactSection />
          </main>

          {/* FOOTER */}
          <Footer />
        </div>

        {/* Global Modals */}
        <SettingsModal />
        <ProjectModal card={selectedCard} onClose={() => setSelectedCard(null)} />
      </div>
    </PortfolioProvider>
  );
};

export default App;
