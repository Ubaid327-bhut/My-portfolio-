import React from 'react';
import { X, Sparkles, Check, ArrowRight, Layers, MessageSquare, ExternalLink } from 'lucide-react';
import { CardData } from './Scroll3DSection';
import { usePortfolio } from '../context/PortfolioContext';

interface ProjectModalProps {
  card: CardData | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ card, onClose }) => {
  const { playSound } = usePortfolio();

  if (!card) return null;

  const handleStartProject = () => {
    playSound('whoosh');
    onClose();
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-2xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#12121A] border border-white/15 p-6 sm:p-10 shadow-2xl text-white">
        {/* Close Button */}
        <button
          onClick={() => {
            playSound('click');
            onClose();
          }}
          className="absolute top-6 right-6 p-2.5 rounded-full bg-white/5 hover:bg-white/15 text-slate-400 hover:text-white transition-colors cursor-pointer z-10"
        >
          <X size={20} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <span
            className="px-3.5 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase"
            style={{
              backgroundColor: `${card.accentColor}20`,
              color: card.accentColor,
              border: `1px solid ${card.accentColor}40`,
            }}
          >
            {card.tag}
          </span>
          <span className="text-slate-500 font-mono text-xs">Blueprint {card.number}</span>
        </div>

        <h2 className="font-montserrat font-extrabold text-3xl sm:text-4xl text-white mb-2">
          {card.title}
        </h2>
        <p className="text-sm font-mono text-slate-400 mb-8 uppercase tracking-wider">
          {card.subtitle}
        </p>

        {/* Browser Mockup Image */}
        <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#0A0A0F] mb-8 shadow-2xl">
          <div className="px-4 py-2.5 bg-[#161622] border-b border-white/10 flex items-center justify-between text-xs font-mono text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
              <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
            </div>
            <span>https://ubaid.dev/architect/{card.id}</span>
            <ExternalLink size={14} />
          </div>
          <div className="relative aspect-video">
            <img
              src={card.image}
              alt={card.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Description & Overview */}
        <div className="mb-8">
          <h4 className="font-montserrat font-bold text-lg text-white mb-2 flex items-center gap-2">
            <Sparkles size={18} className="text-[#00D4FF]" />
            <span>Architecture & Experience Overview</span>
          </h4>
          <p className="text-base text-slate-300 font-inter leading-relaxed">
            {card.description}
          </p>
        </div>

        {/* Deliverables / Features */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
          {card.features.map((feat, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3 text-sm text-slate-200"
            >
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${card.accentColor}30`, color: card.accentColor }}
              >
                <Check size={12} strokeWidth={3} />
              </div>
              <span>{feat}</span>
            </div>
          ))}
        </div>

        {/* Tech Stack Chips */}
        <div className="mb-8">
          <div className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
            <Layers size={14} />
            <span>Core Engineering Stack</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {card.tech.map((t, idx) => (
              <span
                key={idx}
                className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs font-mono text-slate-300"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* Actions Footer */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-slate-400 font-inter text-center sm:text-left">
            Ready to build a <span className="text-white font-semibold">{card.title}</span> with Ubaid?
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-montserrat font-bold cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={handleStartProject}
              className="flex-1 sm:flex-initial px-6 py-3 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white text-xs font-montserrat font-bold uppercase tracking-wider flex items-center justify-center gap-2 hover:shadow-lg transition-transform hover:scale-105 cursor-pointer"
            >
              <MessageSquare size={16} />
              <span>Hire Ubaid for This</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
