import React, { useRef } from 'react';
import { Sparkles, Zap, Smartphone, CheckCircle, ArrowRight, Camera, Terminal, ShieldCheck } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const AboutMe: React.FC = () => {
  const { profilePic, setProfilePic, playSound } = usePortfolio();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setProfilePic(reader.result);
          playSound('success');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const scrollToContact = () => {
    playSound('whoosh');
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="about" className="relative py-28 z-10 overflow-hidden bg-[#0A0A0F]/60">
      {/* Background radial accent */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-[#7C3AED]/15 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#14141F] border border-white/10 text-xs font-mono text-[#00D4FF] mb-3">
            <Sparkles size={12} />
            <span>WHO I AM</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl md:text-7xl tracking-wide uppercase text-white">
            About <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#7C3AED] to-[#00D4FF]">Me</span>
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] rounded-full mt-2" />
        </div>

        {/* Grid: Left Picture / Right Bio & Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: [PICTURE] again on left side */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group w-full max-w-sm sm:max-w-md">
              {/* Outer Neon Glow */}
              <div className="absolute -inset-3 rounded-3xl bg-gradient-to-tr from-[#7C3AED] via-[#00D4FF] to-[#7C3AED] opacity-60 blur-xl group-hover:opacity-90 transition-opacity duration-500" />

              {/* Picture Card Frame */}
              <div className="relative rounded-3xl p-[3px] bg-gradient-to-br from-[#7C3AED] via-[#00D4FF] to-[#7C3AED] shadow-2xl">
                <div className="rounded-[22px] bg-[#0E0E17] overflow-hidden relative">
                  {/* Studio Top Bar */}
                  <div className="px-4 py-2.5 bg-[#141422] border-b border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                      <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                      <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                    </div>
                    <span className="text-[11px] text-slate-400">ubaid_profile.dev</span>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      title="Change / Upload Photo"
                      className="flex items-center gap-1 text-[10px] font-mono text-slate-400 hover:text-[#00D4FF] transition-colors cursor-pointer"
                    >
                      <Camera size={12} />
                      <span>Change</span>
                    </button>
                  </div>

                  {/* Profile Picture */}
                  <div className="relative aspect-[4/5] overflow-hidden group">
                    <img
                      src={profilePic}
                      alt="Ubaid - Developer Profile"
                      className="w-full h-full object-cover object-[center_12%] transition-transform duration-700 group-hover:scale-105"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-transparent to-transparent opacity-80 pointer-events-none" />

                    {/* Upload button overlay */}
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute inset-0 bg-black/50 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-2 text-white cursor-pointer"
                      title="Change / Upload Picture"
                    >
                      <div className="w-12 h-12 rounded-full bg-[#00D4FF] text-black flex items-center justify-center shadow-lg">
                        <Camera size={22} />
                      </div>
                      <span className="text-xs font-montserrat font-bold uppercase tracking-wider bg-black/60 px-3 py-1 rounded-full border border-white/20">
                        Upload Picture
                      </span>
                    </button>

                    {/* Bottom Floating Info Tag */}
                    <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-[#12121A]/90 backdrop-blur-md border border-white/10 flex items-center justify-between">
                      <div>
                        <div className="font-montserrat font-bold text-sm text-white">Ubaid</div>
                        <div className="text-[11px] text-[#00D4FF] font-mono">Senior Web Developer</div>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-1 rounded-md border border-emerald-500/20">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>Ready to build</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Right Column: Bio text & Small Stats */}
          <div className="lg:col-span-7 flex flex-col">
            {/* Terminal pill */}
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mb-4">
              <Terminal size={14} className="text-[#7C3AED]" />
              <span>console.log("Ready to build modern websites")</span>
            </div>

            {/* Sub-headline */}
            <h3 className="font-montserrat font-extrabold text-2xl sm:text-3xl text-white mb-6 leading-tight">
              Crafting <span className="text-[#00D4FF]">Cinematic Web Experiences</span> with Clean Code & 3D Immersion.
            </h3>

            {/* EXACT TEXT REQUESTED:
                "Hi, I'm Ubaid. I can create every type of website - Portfolio websites, 3D animated websites, Simple websites, Business / Work websites, and more. If you need any website or app, contact me. I build fast, modern, and fully responsive websites."
            */}
            <div className="p-6 rounded-2xl bg-[#12121A]/80 border border-white/10 backdrop-blur-md mb-8 relative">
              <div className="absolute top-0 left-6 -translate-y-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-[10px] font-bold tracking-wider uppercase text-white">
                Developer Statement
              </div>
              <p className="text-base sm:text-lg text-slate-200 font-inter leading-relaxed">
                "Hi, I'm Ubaid. I can create every type of website —{' '}
                <strong className="text-white font-semibold">
                  Portfolio websites, 3D animated websites, Simple websites, Business / Work websites, and more.
                </strong>{' '}
                If you need any website or app, contact me. I build fast, modern, and fully responsive websites."
              </p>
            </div>

            {/* SMALL STATS: 50+ Projects, 100% Responsive, Fast Delivery */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              {/* Stat 1 */}
              <div className="p-4 rounded-xl bg-[#12121A]/60 border border-white/10 hover:border-[#7C3AED]/50 transition-all duration-300 group">
                <div className="w-10 h-10 rounded-lg bg-[#7C3AED]/20 text-[#7C3AED] flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <CheckCircle size={20} />
                </div>
                <div className="font-bebas text-3xl sm:text-4xl text-white tracking-wide">
                  50+ Projects
                </div>
                <p className="text-xs text-slate-400 font-inter mt-1">
                  Completed & deployed successfully with happy clients
                </p>
              </div>

              {/* Stat 2 */}
              <div className="p-4 rounded-xl bg-[#12121A]/60 border border-white/10 hover:border-[#00D4FF]/50 transition-all duration-300 group">
                <div className="w-10 h-10 rounded-lg bg-[#00D4FF]/20 text-[#00D4FF] flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Smartphone size={20} />
                </div>
                <div className="font-bebas text-3xl sm:text-4xl text-white tracking-wide">
                  100% Responsive
                </div>
                <p className="text-xs text-slate-400 font-inter mt-1">
                  Pixel-perfect across mobile, tablet, laptop, and 4K displays
                </p>
              </div>

              {/* Stat 3 */}
              <div className="p-4 rounded-xl bg-[#12121A]/60 border border-white/10 hover:border-[#7C3AED]/50 transition-all duration-300 group">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Zap size={20} />
                </div>
                <div className="font-bebas text-3xl sm:text-4xl text-white tracking-wide">
                  Fast Delivery
                </div>
                <p className="text-xs text-slate-400 font-inter mt-1">
                  Rapid prototyping, agile communication & on-time launches
                </p>
              </div>
            </div>

            {/* Quick Guarantees & CTA */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10">
              <div className="flex items-center gap-3 text-xs text-slate-400">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <ShieldCheck size={16} className="text-[#00D4FF]" />
                  <span>Clean & Scalable Code</span>
                </div>
                <span className="text-white/20">•</span>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Zap size={16} className="text-[#7C3AED]" />
                  <span>SEO & Performance Optimized</span>
                </div>
              </div>

              <button
                onClick={scrollToContact}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-[#00D4FF] text-white text-xs font-montserrat font-bold uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Hire Ubaid Now</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
