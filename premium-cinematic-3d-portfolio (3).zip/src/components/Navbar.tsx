import React, { useState, useEffect } from 'react';
import { Sparkles, MessageCircle, Settings, Volume2, VolumeX, Menu, X, ArrowUpRight } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Navbar: React.FC = () => {
  const { isSettingsOpen, setIsSettingsOpen, soundEnabled, setSoundEnabled, playSound, whatsapp } = usePortfolio();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    playSound('whoosh');
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cleanWhatsapp = whatsapp.replace(/\D/g, '');

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'py-3.5 bg-[#0A0A0F]/85 backdrop-blur-xl border-b border-white/10 shadow-2xl shadow-black/80'
          : 'py-6 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <button
            onClick={() => scrollToSection('hero')}
            className="flex items-center gap-2.5 group cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7C3AED] to-[#00D4FF] p-[1.5px] transition-transform duration-300 group-hover:scale-105">
              <div className="w-full h-full bg-[#0A0A0F] rounded-[10px] flex items-center justify-center">
                <span className="font-bebas text-2xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-[#00D4FF]">
                  U
                </span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-montserrat font-bold text-lg text-white tracking-wider">
                  UBAID
                </span>
                <span className="w-2 h-2 rounded-full bg-[#00D4FF] animate-pulse"></span>
              </div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 block -mt-1">
                Web Developer
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#12121A]/70 backdrop-blur-md border border-white/10 rounded-full px-4 py-1.5 shadow-lg shadow-black/40">
            <button
              onClick={() => scrollToSection('about')}
              className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-full transition-all duration-200 hover:bg-white/5 cursor-pointer"
            >
              About Me
            </button>
            <button
              onClick={() => scrollToSection('scroll-3d')}
              className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-full transition-all duration-200 hover:bg-white/5 cursor-pointer"
            >
              3D Scroll
            </button>
            <button
              onClick={() => scrollToSection('services-work')}
              className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-full transition-all duration-200 hover:bg-white/5 cursor-pointer"
            >
              My Work
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-full transition-all duration-200 hover:bg-white/5 cursor-pointer"
            >
              Contact With Me
            </button>
          </nav>

          {/* Action Tools */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Audio Toggle */}
            <button
              onClick={() => {
                setSoundEnabled(!soundEnabled);
                playSound('click');
              }}
              className={`p-2.5 rounded-full border transition-all duration-200 cursor-pointer ${
                soundEnabled
                  ? 'border-[#00D4FF]/40 bg-[#00D4FF]/10 text-[#00D4FF]'
                  : 'border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20'
              }`}
              title={soundEnabled ? 'Mute Sound FX' : 'Enable Cyber Sound FX'}
              aria-label="Toggle Sound"
            >
              {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>

            {/* Custom Settings (Photo, Email, Phone) */}
            <button
              onClick={() => {
                setIsSettingsOpen(!isSettingsOpen);
                playSound('click');
              }}
              className="p-2.5 rounded-full border border-white/10 bg-white/5 text-slate-400 hover:text-[#7C3AED] hover:border-[#7C3AED]/40 hover:bg-[#7C3AED]/10 transition-all duration-200 cursor-pointer"
              title="Profile & Contact Settings"
              aria-label="Settings"
            >
              <Settings size={16} />
            </button>

            {/* Direct WhatsApp Quick Chat */}
            <a
              href={`https://wa.me/${cleanWhatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound('click')}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#25D366]/15 border border-[#25D366]/40 text-[#25D366] text-xs font-medium hover:bg-[#25D366]/25 hover:border-[#25D366] transition-all duration-200"
            >
              <MessageCircle size={14} className="animate-pulse" />
              <span>WhatsApp</span>
            </a>

            {/* Contact CTA */}
            <button
              onClick={() => scrollToSection('contact')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white text-xs font-semibold tracking-wide hover:shadow-[0_0_25px_rgba(0,212,255,0.4)] transition-all duration-300 hover:scale-[1.02] cursor-pointer"
            >
              <Sparkles size={14} />
              <span>Let's Talk</span>
              <ArrowUpRight size={14} />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-300"
              aria-label="Settings"
            >
              <Settings size={18} />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-300"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 px-6 bg-[#0E0E17]/95 backdrop-blur-2xl rounded-2xl border border-white/10 shadow-2xl animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex flex-col gap-3">
              <button
                onClick={() => scrollToSection('about')}
                className="text-left py-2 text-sm font-medium text-slate-200 hover:text-[#00D4FF] border-b border-white/5"
              >
                About Me
              </button>
              <button
                onClick={() => scrollToSection('scroll-3d')}
                className="text-left py-2 text-sm font-medium text-slate-200 hover:text-[#00D4FF] border-b border-white/5"
              >
                3D Scroll Animation
              </button>
              <button
                onClick={() => scrollToSection('services-work')}
                className="text-left py-2 text-sm font-medium text-slate-200 hover:text-[#00D4FF] border-b border-white/5"
              >
                Services / My Work
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="text-left py-2 text-sm font-medium text-slate-200 hover:text-[#00D4FF] border-b border-white/5"
              >
                Contact With Me
              </button>
              <div className="flex items-center gap-3 pt-2">
                <a
                  href={`https://wa.me/${cleanWhatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 text-center py-2.5 rounded-xl bg-[#25D366]/20 border border-[#25D366]/50 text-[#25D366] text-xs font-semibold flex items-center justify-center gap-2"
                >
                  <MessageCircle size={15} />
                  <span>WhatsApp</span>
                </a>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="flex-1 text-center py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white text-xs font-semibold"
                >
                  Contact Me
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
