import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Sparkles, ArrowUpRight, Layers } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

gsap.registerPlugin(ScrollTrigger);

export interface CardData {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  tag: string;
  description: string;
  image: string;
  features: string[];
  tech: string[];
  accentColor: string;
  glowColor: string;
}

const CARDS_DATA: CardData[] = [
  {
    id: '3d-website',
    number: '01',
    title: '3D Website',
    subtitle: 'WebGL • Three.js • GSAP Shaders',
    tag: 'Cinematic 3D Experience',
    description:
      'Immersive 3D environments with real-time lighting, interactive camera tracks, floating metallic chrome shapes, and custom shaders that captivate every visitor.',
    image: '/images/project-3d.jpg',
    features: ['Realtime WebGL Canvas', 'Interactive Mouse Parallax', 'Scroll-driven 3D Scrub', '60 FPS Performance'],
    tech: ['Three.js', 'WebGL', 'GSAP', 'GLSL Shaders', 'React'],
    accentColor: '#7C3AED',
    glowColor: 'rgba(124, 58, 237, 0.4)',
  },
  {
    id: 'simple-website',
    number: '02',
    title: 'Simple Website',
    subtitle: 'Ultra Minimal • Swiss Style • Fast',
    tag: 'Sleek & Zero Clutter',
    description:
      'Clean, distraction-free modern websites with bold typography, dark studio elegance, and sub-second load times. Apple & A24 aesthetic for portfolios and boutique agencies.',
    image: '/images/project-minimal.jpg',
    features: ['Sub-second Load Times', 'Flawless Typography', '100% SEO & Performance', 'Mobile-First Layout'],
    tech: ['Next.js / Vite', 'Tailwind CSS', 'Framer Motion', 'TypeScript'],
    accentColor: '#00D4FF',
    glowColor: 'rgba(0, 212, 255, 0.4)',
  },
  {
    id: 'business-website',
    number: '03',
    title: 'Work / Business Website',
    subtitle: 'Enterprise • High Conversion • SaaS',
    tag: 'Corporate & Lead Capture',
    description:
      'High-converting business platforms built to scale. Complete with interactive service showcases, automated lead forms, WhatsApp integrations, and solid brand authority.',
    image: '/images/project-business.jpg',
    features: ['Lead Generation Forms', 'Trust Authority Layout', 'CRM & WhatsApp Chat', 'Security & Speed'],
    tech: ['React', 'Node.js', 'PostgreSQL', 'Tailwind', 'Stripe/API'],
    accentColor: '#7C3AED',
    glowColor: 'rgba(124, 58, 237, 0.4)',
  },
  {
    id: 'custom-website-apps',
    number: '04',
    title: 'More / Custom Website & Apps',
    subtitle: 'Full-Stack • Client Portals • APIs',
    tag: 'Tailored Web Applications',
    description:
      'Bespoke web applications and custom software platforms designed from scratch. Fast reactive state management, seamless database synchronization, and scalable cloud deployment.',
    image: '/images/project-app.jpg',
    features: ['Custom Web Portals', 'Authentication & Roles', 'Real-time Dashboards', 'REST / GraphQL APIs'],
    tech: ['React 19', 'Next.js', 'Supabase', 'Tailwind', 'TypeScript'],
    accentColor: '#00D4FF',
    glowColor: 'rgba(0, 212, 255, 0.4)',
  },
];

interface Scroll3DSectionProps {
  onSelectCard: (card: CardData) => void;
}

export const Scroll3DSection: React.FC<Scroll3DSectionProps> = ({ onSelectCard }) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsContainerRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const { playSound } = usePortfolio();

  // 3D Card tilt state
  const [tilt, setTilt] = useState<{ [key: number]: { x: number; y: number } }>({});

  const handleCardMouseMove = (e: React.MouseEvent<HTMLDivElement>, index: number) => {
    const card = cardRefs.current[index];
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -12;
    const rotateY = ((x - centerX) / centerX) * 12;

    setTilt((prev) => ({
      ...prev,
      [index]: { x: rotateX, y: rotateY },
    }));
  };

  const handleCardMouseLeave = (index: number) => {
    setTilt((prev) => ({
      ...prev,
      [index]: { x: 0, y: 0 },
    }));
  };

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // 3D Scroll animation: cards move up, scale, and rotate in 3D smoothly with scrub: 1
      cardRefs.current.forEach((card, index) => {
        if (!card) return;

        gsap.fromTo(
          card,
          {
            y: 120 + index * 40,
            scale: 0.88,
            rotationX: 18,
            rotationY: index % 2 === 0 ? -8 : 8,
            opacity: 0.4,
            transformPerspective: 1200,
          },
          {
            y: 0,
            scale: 1,
            rotationX: 0,
            rotationY: 0,
            opacity: 1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 40%',
              scrub: 1, // exact scrub effect follows mouse scroll
              invalidateOnRefresh: true,
            },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="scroll-3d"
      ref={sectionRef}
      className="relative py-32 z-10 overflow-hidden bg-[#0A0A0F]"
    >
      {/* Background cyber grid & glow */}
      <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-[#00D4FF]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-10 w-96 h-96 bg-[#7C3AED]/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="flex flex-col items-center text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#12121A] border border-white/10 text-xs font-mono text-[#00D4FF] mb-4">
            <Layers size={14} />
            <span>GSAP SCROLLTRIGGER + 3D SCRUB</span>
          </div>

          <h2 className="font-bebas text-5xl sm:text-6xl md:text-8xl tracking-wide uppercase text-white mb-4">
            3D Scroll <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#7C3AED] via-[#A855F7] to-[#00D4FF]">Animation</span>
          </h2>

          <p className="max-w-2xl text-slate-400 font-inter text-base sm:text-lg">
            Scroll down to watch sections transform in 3D perspective — moving up, scaling, and rotating dynamically with your mouse wheel.
          </p>

          <div className="w-24 h-1 bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] rounded-full mt-4" />
        </div>

        {/* 4 Cards in 3D Animation Grid */}
        <div
          ref={cardsContainerRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 perspective-1000"
        >
          {CARDS_DATA.map((card, index) => {
            const currentTilt = tilt[index] || { x: 0, y: 0 };

            return (
              <div
                key={card.id}
                ref={(el) => {
                  cardRefs.current[index] = el;
                }}
                onMouseMove={(e) => handleCardMouseMove(e, index)}
                onMouseLeave={() => handleCardMouseLeave(index)}
                onClick={() => {
                  playSound('whoosh');
                  onSelectCard(card);
                }}
                className="transform-style-3d cursor-pointer group"
                style={{
                  transform: `perspective(1000px) rotateX(${currentTilt.x}deg) rotateY(${currentTilt.y}deg) translateZ(0)`,
                  transition: 'transform 0.15s ease-out',
                }}
              >
                {/* Outer Glow on Hover */}
                <div
                  className="rounded-3xl p-[1.5px] transition-all duration-500 relative"
                  style={{
                    background: `linear-gradient(135deg, rgba(255,255,255,0.1), ${card.accentColor}66, rgba(255,255,255,0.05))`,
                    boxShadow: currentTilt.x !== 0 ? `0 20px 40px -10px ${card.glowColor}` : 'none',
                  }}
                >
                  <div className="rounded-[22px] bg-[#101018]/90 backdrop-blur-xl p-6 sm:p-8 flex flex-col justify-between h-full border border-white/5 relative overflow-hidden group-hover:border-white/20 transition-colors">
                    {/* Top Corner Number & Icon */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <span className="font-bebas text-4xl sm:text-5xl text-white/20 group-hover:text-white transition-colors duration-300">
                          {card.number}
                        </span>
                        <div className="h-6 w-px bg-white/10" />
                        <span
                          className="px-3 py-1 rounded-full text-xs font-mono font-semibold tracking-wider uppercase"
                          style={{
                            backgroundColor: `${card.accentColor}20`,
                            color: card.accentColor,
                            border: `1px solid ${card.accentColor}40`,
                          }}
                        >
                          {card.tag}
                        </span>
                      </div>

                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110 group-hover:rotate-45"
                        style={{ backgroundColor: `${card.accentColor}20`, color: card.accentColor }}
                      >
                        <ArrowUpRight size={20} />
                      </div>
                    </div>

                    {/* Card Title & Subtitle */}
                    <div className="mb-4">
                      <h3 className="font-montserrat font-extrabold text-2xl sm:text-3xl text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-[#00D4FF] transition-all duration-300">
                        {card.title}
                      </h3>
                      <p className="text-xs font-mono text-slate-400 mt-1 uppercase tracking-wider">
                        {card.subtitle}
                      </p>
                    </div>

                    {/* Card Mockup Visual Image with 3D Depth */}
                    <div className="relative rounded-2xl overflow-hidden mb-6 aspect-video border border-white/10 bg-[#0A0A0F] group-hover:border-white/30 transition-all duration-500 shadow-xl">
                      <img
                        src={card.image}
                        alt={card.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#101018] via-transparent to-transparent opacity-80" />

                      {/* Floating View Blueprint Tag */}
                      <div className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-md border border-white/20 text-[11px] font-mono text-white flex items-center gap-1.5 opacity-90 group-hover:opacity-100">
                        <Sparkles size={12} className="text-[#00D4FF]" />
                        <span>Interactive Demo</span>
                      </div>
                    </div>

                    {/* Card Description */}
                    <p className="text-sm text-slate-300 font-inter leading-relaxed mb-6">
                      {card.description}
                    </p>

                    {/* Feature Chips */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      {card.features.map((feat, fIdx) => (
                        <div
                          key={fIdx}
                          className="flex items-center gap-2 text-xs text-slate-300 font-inter bg-white/5 rounded-lg px-2.5 py-1.5 border border-white/5"
                        >
                          <span
                            className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: card.accentColor }}
                          />
                          <span className="truncate">{feat}</span>
                        </div>
                      ))}
                    </div>

                    {/* Tech Footer Badges */}
                    <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex flex-wrap gap-1.5">
                        {card.tech.slice(0, 3).map((t, tIdx) => (
                          <span
                            key={tIdx}
                            className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/5"
                          >
                            {t}
                          </span>
                        ))}
                      </div>

                      <span className="text-xs font-montserrat font-bold text-[#00D4FF] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        <span>Click to Inspect</span>
                        <ArrowUpRight size={14} />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
