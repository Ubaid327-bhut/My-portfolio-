import React, { useState, useRef } from 'react';
import { X, Camera, Mail, MessageCircle, RotateCcw, Check, Sparkles, Upload } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsOpen,
    setIsSettingsOpen,
    profilePic,
    setProfilePic,
    email,
    setEmail,
    whatsapp,
    setWhatsapp,
    resetToDefaults,
    playSound,
  } = usePortfolio();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [localEmail, setLocalEmail] = useState(email);
  const [localPhone, setLocalPhone] = useState(whatsapp);
  const [savedToast, setSavedToast] = useState(false);

  if (!isSettingsOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setProfilePic(reader.result);
          playSound('success');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setEmail(localEmail);
    setWhatsapp(localPhone);
    playSound('success');
    setSavedToast(true);
    setTimeout(() => {
      setSavedToast(false);
      setIsSettingsOpen(false);
    }, 1200);
  };

  const handleReset = () => {
    resetToDefaults();
    setLocalEmail('obaidabbasi767@gmail.com');
    setLocalPhone('03338342392');
    playSound('click');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#12121A] border border-white/15 p-6 sm:p-8 shadow-2xl shadow-purple-950/40 text-white">
        {/* Close Button */}
        <button
          onClick={() => {
            playSound('click');
            setIsSettingsOpen(false);
          }}
          className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#7C3AED] to-[#00D4FF] p-[1px]">
            <div className="w-full h-full bg-[#12121A] rounded-[11px] flex items-center justify-center text-[#00D4FF]">
              <Sparkles size={20} />
            </div>
          </div>
          <div>
            <h3 className="font-montserrat font-bold text-xl text-white">
              Profile & Contact Settings
            </h3>
            <p className="text-xs text-slate-400 font-inter">
              Customize profile photo, email address, and WhatsApp number.
            </p>
          </div>
        </div>

        {savedToast && (
          <div className="mb-6 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-mono flex items-center gap-2 animate-in fade-in">
            <Check size={16} />
            <span>Settings saved successfully! Updated across all sections.</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-6">
          {/* Profile Picture Upload Section */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-4">
            <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-[#00D4FF] shrink-0 bg-[#0A0A0F]">
              <img
                src={profilePic}
                alt="Current profile"
                className="w-full h-full object-cover object-[center_15%]"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer"
                title="Change Photo"
              >
                <Camera size={18} className="text-white" />
              </button>
            </div>

            <div className="flex-1">
              <div className="text-xs font-montserrat font-bold text-white mb-1">
                Profile Picture [PICTURE]
              </div>
              <p className="text-[11px] text-slate-400 font-inter mb-2">
                Upload your custom photo to replace avatar in Hero & About sections.
              </p>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-mono text-slate-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Upload size={13} />
                <span>Upload From Computer</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Email setting */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-2">
              Recipient Email Address
            </label>
            <div className="relative">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                required
                value={localEmail}
                onChange={(e) => setLocalEmail(e.target.value)}
                placeholder="e.g. obaidabbasi767@gmail.com"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-white/10 text-white text-sm font-inter focus:outline-none focus:border-[#7C3AED]"
              />
            </div>
            <span className="text-[10px] text-slate-500 font-mono mt-1 block">
              Default: obaidabbasi767@gmail.com
            </span>
          </div>

          {/* WhatsApp setting */}
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-2">
              WhatsApp Number
            </label>
            <div className="relative">
              <MessageCircle size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                required
                value={localPhone}
                onChange={(e) => setLocalPhone(e.target.value)}
                placeholder="e.g. 03338342392"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#0A0A0F] border border-white/10 text-white text-sm font-inter focus:outline-none focus:border-[#25D366]"
              />
            </div>
            <span className="text-[10px] text-slate-500 font-mono mt-1 block">
              Default: 03338342392 (Automatically formats for wa.me link)
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={handleReset}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white text-xs font-mono flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw size={14} />
              <span>Reset Defaults</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsSettingsOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-transparent hover:bg-white/5 text-slate-400 text-xs font-montserrat font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white text-xs font-montserrat font-bold tracking-wider uppercase hover:shadow-lg transition-transform hover:scale-105 cursor-pointer"
              >
                Save Settings
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
