import React, { useRef } from 'react';
import { Sparkles, ArrowRight, MessageSquare, Camera, CheckCircle2, ChevronDown } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Hero: React.FC = () => {
  const { profilePic, setProfilePic, playSound } = usePortfolio();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setProfilePic(reader.result);
          playSound('success');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const scrollToSection = (id: string) => {
    playSound('whoosh');
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-32 pb-20 flex flex-col justify-center items-center overflow-hidden z-10"
    >
      {/* Background ambient light blooms */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-[#7C3AED]/20 rounded-full blur-[120px] pointer-events-none animate-pulse-glow" />
      <div className="absolute top-1/3 -right-20 w-96 h-96 bg-[#00D4FF]/20 rounded-full blur-[140px] pointer-events-none animate-pulse-glow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left / Center Content Column */}
          <div className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left">
            {/* Top Status Pill */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#12121A]/80 border border-white/10 backdrop-blur-md mb-6 shadow-inner">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00D4FF] animate-ping" />
              <span className="text-xs uppercase font-mono tracking-wider text-slate-300">
                Interactive 3D Portfolio • 2026 Edition
              </span>
              <span className="text-xs text-[#7C3AED] font-semibold flex items-center gap-1">
                <Sparkles size={12} />
              </span>
            </div>

            {/* BIG BOLD NAME: UBAID with 3D Chrome Metallic effect & purple/blue rim light */}
            <div className="relative mb-4 group select-none">
              <h1 className="font-bebas text-7xl sm:text-8xl md:text-9xl lg:text-[10rem] tracking-tight leading-[0.88] chrome-metallic-text uppercase transition-transform duration-300 hover:scale-[1.01]">
                Ubaid
              </h1>
              {/* Subtle metallic rim light reflection highlights */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[#7C3AED]/30 via-transparent to-[#00D4FF]/30 blur-2xl opacity-75 -z-10 pointer-events-none" />
            </div>

            {/* Subtitle Role Tag */}
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-8 bg-gradient-to-r from-[#7C3AED] to-transparent hidden sm:block" />
              <p className="font-mono text-sm sm:text-base uppercase tracking-widest text-[#00D4FF] font-semibold">
                Creative Web Developer & 3D Specialist
              </p>
              <div className="h-px w-8 bg-gradient-to-l from-[#00D4FF] to-transparent hidden sm:block" />
            </div>

            {/* TAGLINE: "I build every type of website - Portfolios, 3D Websites, Business Websites, and more." */}
            <p className="text-lg sm:text-xl lg:text-2xl text-slate-300 font-inter font-normal max-w-2xl leading-relaxed mb-8">
              I build every type of website —{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-[#00D4FF] font-medium">
                Portfolios, 3D Websites, Business Websites,
              </span>{' '}
              and more.
            </p>

            {/* NAVIGATION SECTIONS: [About Me] [Contact With Me] [More] */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 mb-9 p-1.5 rounded-2xl bg-[#12121A]/60 border border-white/10 backdrop-blur-md">
              <button
                onClick={() => scrollToSection('about')}
                className="px-4 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-200 hover:text-white hover:bg-white/10 transition-all duration-200 cursor-pointer flex items-center gap-1.5"
              >
                <span>About Me</span>
              </button>
              <span className="text-white/20 select-none">•</span>
              <button
                onClick={() => scrollToSection('contact')}
                className="px-4 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-200 hover:text-white hover:bg-white/10 transition-all duration-200 cursor-pointer flex items-center gap-1.5"
              >
                <span>Contact With Me</span>
              </button>
              <span className="text-white/20 select-none">•</span>
              <button
                onClick={() => scrollToSection('services-work')}
                className="px-4 py-2 rounded-xl text-xs sm:text-sm font-medium text-[#00D4FF] hover:text-white hover:bg-[#00D4FF]/10 transition-all duration-200 cursor-pointer flex items-center gap-1.5"
              >
                <span>More</span>
                <ChevronDown size={14} />
              </button>
            </div>

            {/* 2 MAIN CTA BUTTONS: "View My Work" and "Contact Me" */}
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
              <button
                onClick={() => scrollToSection('services-work')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#5B21B6] to-[#00D4FF] text-white font-montserrat font-bold text-sm tracking-wider uppercase hover:shadow-[0_0_35px_rgba(124,58,237,0.5)] transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2.5 group"
              >
                <span>View My Work</span>
                <ArrowRight size={18} className="transition-transform duration-300 group-hover:translate-x-1" />
              </button>

              <button
                onClick={() => scrollToSection('contact')}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-[#14141E]/90 hover:bg-[#1C1C2B] text-white font-montserrat font-bold text-sm tracking-wider uppercase border border-white/15 hover:border-[#00D4FF]/60 hover:shadow-[0_0_25px_rgba(0,212,255,0.25)] transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2.5"
              >
                <MessageSquare size={18} className="text-[#00D4FF]" />
                <span>Contact Me</span>
              </button>
            </div>

            {/* Tech Badges */}
            <div className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs font-mono text-slate-400">
              <span className="text-slate-500">Specialized In:</span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300">Three.js</span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300">WebGL</span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300">React</span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300">GSAP</span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300">Tailwind CSS</span>
            </div>
          </div>

          {/* Right Column: [PICTURE] - User profile picture circular with neon purple-blue glow border */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center">
            <div className="relative group">
              {/* Outer Neon Glow Rings */}
              <div className="absolute -inset-4 rounded-full bg-gradient-to-tr from-[#7C3AED] via-[#00D4FF] to-[#7C3AED] opacity-70 blur-xl group-hover:opacity-100 transition-opacity duration-500 animate-pulse-glow" />

              {/* Decorative Rotating Border Ring */}
              <div className="absolute -inset-2 rounded-full border border-dashed border-[#00D4FF]/40 animate-[spin_20s_linear_infinite] pointer-events-none" />

              {/* Main Circular Profile Picture Frame */}
              <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 rounded-full p-[4px] bg-gradient-to-tr from-[#7C3AED] via-[#00D4FF] to-[#7C3AED] shadow-[0_0_50px_rgba(124,58,237,0.45),0_0_70px_rgba(0,212,255,0.35)]">
                <div className="w-full h-full rounded-full overflow-hidden bg-[#0A0A0F] relative">
                  <img
                    src={profilePic}
                    alt="Ubaid - Web Developer Profile"
                    className="w-full h-full object-cover object-[center_15%] transition-transform duration-700 group-hover:scale-105"
                  />

                  {/* Gradient Shadow Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F]/70 via-transparent to-transparent pointer-events-none" />

                  {/* Hover Upload Button */}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-2 cursor-pointer text-white"
                    title="Upload Custom Profile Picture"
                  >
                    <div className="w-12 h-12 rounded-full bg-[#7C3AED] flex items-center justify-center shadow-lg">
                      <Camera size={22} className="text-white" />
                    </div>
                    <span className="text-xs font-montserrat font-bold tracking-wider uppercase text-white bg-black/40 px-3 py-1 rounded-full border border-white/20">
                      Upload Picture
                    </span>
                  </button>
                </div>
              </div>

              {/* Hidden file input for user picture upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />

              {/* Floating Stat Pill Top-Right */}
              <div className="absolute -top-3 -right-2 sm:top-4 sm:right-0 bg-[#12121A]/90 backdrop-blur-md border border-[#00D4FF]/40 rounded-2xl px-4 py-2.5 shadow-2xl flex items-center gap-2.5 animate-bounce [animation-duration:4s]">
                <div className="w-8 h-8 rounded-xl bg-[#00D4FF]/20 flex items-center justify-center text-[#00D4FF]">
                  <CheckCircle2 size={18} />
                </div>
                <div>
                  <div className="text-xs font-bold text-white font-montserrat">50+ Projects</div>
                  <div className="text-[10px] text-slate-400">Shipped Worldwide</div>
                </div>
              </div>

              {/* Floating Stat Pill Bottom-Left */}
              <div className="absolute -bottom-3 -left-2 sm:bottom-4 sm:left-0 bg-[#12121A]/90 backdrop-blur-md border border-[#7C3AED]/40 rounded-2xl px-4 py-2.5 shadow-2xl flex items-center gap-2.5 animate-bounce [animation-duration:5s]">
                <div className="w-8 h-8 rounded-xl bg-[#7C3AED]/20 flex items-center justify-center text-[#7C3AED]">
                  <Sparkles size={18} />
                </div>
                <div>
                  <div className="text-xs font-bold text-white font-montserrat">100% Responsive</div>
                  <div className="text-[10px] text-slate-400">Ultra-fast 3D UI</div>
                </div>
              </div>
            </div>

            {/* Quick Upload Button - works on mobile + desktop, pulses until real photo is set */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`mt-6 flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-montserrat font-bold tracking-wider uppercase transition-all duration-200 cursor-pointer border ${
                profilePic.startsWith('data:')
                  ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:border-[#00D4FF]/50 hover:bg-white/10'
                  : 'bg-[#00D4FF]/10 border-[#00D4FF]/50 text-[#00D4FF] animate-pulse'
              }`}
            >
              <Camera size={14} />
              <span>{profilePic.startsWith('data:') ? 'Change Photo' : 'Set Your Photo'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
