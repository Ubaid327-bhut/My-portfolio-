import React, { useState } from 'react';
import { Sparkles, Globe, Box, Building2, Code2, ArrowUpRight, Check, Monitor, Tablet, Smartphone } from 'lucide-react';
import { CardData } from './Scroll3DSection';
import { usePortfolio } from '../context/PortfolioContext';

export interface ServiceWorkItem {
  id: string;
  category: 'Portfolio Website' | '3D Website' | 'Business Website' | 'App Development';
  title: string;
  tagline: string;
  description: string;
  image: string;
  icon: typeof Globe;
  deliverables: string[];
  techStack: string[];
  estimatedDays: string;
  accent: string;
}

const SERVICES_DATA: ServiceWorkItem[] = [
  {
    id: 'portfolio-website',
    category: 'Portfolio Website',
    title: 'Cinematic Developer & Creator Portfolios',
    tagline: 'High-Impact Brand Identity & Modern Showcase',
    description:
      'Turn visitors into clients with an unforgettable personal or agency portfolio. Features smooth micro-interactions, dark luxury aesthetics, responsive design, and seamless contact pathways.',
    image: '/images/project-minimal.jpg',
    icon: Globe,
    deliverables: [
      'Tailored Visual Identity & Custom Fonts',
      '100% Mobile & 4K Responsive Layouts',
      'Automated Contact & WhatsApp Routing',
      'SEO Structured Data & Fast Indexing',
    ],
    techStack: ['React', 'Next.js', 'Tailwind CSS', 'Vite', 'GSAP'],
    estimatedDays: '3 - 5 Days',
    accent: '#00D4FF',
  },
  {
    id: '3d-website',
    category: '3D Website',
    title: 'Full 3D WebGL Interactive Experiences',
    tagline: 'Real-Time 3D Models, Shaders & Camera Tracking',
    description:
      'Next-generation web experiences built with Three.js and WebGL. Interactive floating chrome objects, particle effects, spatial mouse parallax, and scroll-driven 3D camera animations.',
    image: '/images/project-3d.jpg',
    icon: Box,
    deliverables: [
      'Custom WebGL / Three.js 3D Canvas',
      'Realistic Lighting, Chrome & Glass Shaders',
      'Scroll-Driven Camera scrubbing (GSAP)',
      'Optimized 60 FPS for Mobile & Desktop',
    ],
    techStack: ['Three.js', 'WebGL', 'GLSL', 'React Three Fiber', 'GSAP'],
    estimatedDays: '5 - 8 Days',
    accent: '#7C3AED',
  },
  {
    id: 'business-website',
    category: 'Business Website',
    title: 'Enterprise & High-Converting Business Sites',
    tagline: 'Corporate Authority, Lead Capture & Scalability',
    description:
      'Professional corporate and startup websites designed to generate qualified leads and establish unquestioned industry authority. Fast, secure, and integrated with your business tools.',
    image: '/images/project-business.jpg',
    icon: Building2,
    deliverables: [
      'Conversion-Optimized Sales Architecture',
      'Interactive Services & Pricing Tiers',
      'Instant WhatsApp Chat & Email Lead Engine',
      'Enterprise Speed, SSL Security & SEO',
    ],
    techStack: ['React', 'Tailwind CSS', 'Node.js', 'PostgreSQL', 'Vercel'],
    estimatedDays: '5 - 10 Days',
    accent: '#00D4FF',
  },
  {
    id: 'app-development',
    category: 'App Development',
    title: 'Modern Web Applications & Custom Dashboards',
    tagline: 'Full-Stack Scalability, Real-Time Data & Clean APIs',
    description:
      'Custom-built web applications, SaaS dashboards, and client portals with reactive UI state, rock-solid security, database synchronization, and scalable cloud deployment.',
    image: '/images/project-app.jpg',
    icon: Code2,
    deliverables: [
      'Custom Responsive UI/UX Dashboard',
      'Real-Time Analytics & Data Visualization',
      'Secure User Authentication & Access Control',
      'RESTful & GraphQL API Integrations',
    ],
    techStack: ['React 19', 'TypeScript', 'Node.js', 'Supabase', 'Tailwind'],
    estimatedDays: '7 - 14 Days',
    accent: '#7C3AED',
  },
];

interface ServicesWorkProps {
  onInspectService: (card: CardData) => void;
}

export const ServicesWork: React.FC<ServicesWorkProps> = ({ onInspectService }) => {
  const [activeTab, setActiveTab] = useState<string>('All');
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const { playSound } = usePortfolio();

  const filteredItems =
    activeTab === 'All'
      ? SERVICES_DATA
      : SERVICES_DATA.filter((s) => s.category.toLowerCase().includes(activeTab.toLowerCase()));

  const handleCardClick = (item: ServiceWorkItem) => {
    playSound('whoosh');
    const convertedCard: CardData = {
      id: item.id,
      number: '0' + (SERVICES_DATA.findIndex((s) => s.id === item.id) + 1),
      title: item.category,
      subtitle: item.tagline,
      tag: item.category,
      description: item.description,
      image: item.image,
      features: item.deliverables,
      tech: item.techStack,
      accentColor: item.accent,
      glowColor: item.accent === '#7C3AED' ? 'rgba(124, 58, 237, 0.4)' : 'rgba(0, 212, 255, 0.4)',
    };
    onInspectService(convertedCard);
  };

  const scrollToContact = () => {
    playSound('whoosh');
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="services-work" className="relative py-32 z-10 overflow-hidden bg-[#0A0A0F]/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141422] border border-white/10 text-xs font-mono text-[#7C3AED] mb-4">
            <Sparkles size={14} />
            <span>SOLUTIONS & WEB WORK</span>
          </div>

          <h2 className="font-bebas text-5xl sm:text-6xl md:text-8xl tracking-wide uppercase text-white mb-4">
            Services / <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00D4FF] to-[#7C3AED]">My Work</span>
          </h2>

          <p className="max-w-2xl text-slate-400 font-inter text-base sm:text-lg">
            A specialized grid of the 4 core web disciplines I build — strictly portfolio & web engineering, no clutter.
          </p>

          <div className="w-24 h-1 bg-gradient-to-r from-[#00D4FF] to-[#7C3AED] rounded-full mt-4" />
        </div>

        {/* Filter Controls & Device Mockup Selector */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-12 p-2 rounded-2xl bg-[#12121A]/70 border border-white/10 backdrop-blur-md">
          {/* Category Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
            {['All', 'Portfolio', '3D Website', 'Business', 'App'].map((tab) => (
              <button
                key={tab}
                onClick={() => {
                  setActiveTab(tab);
                  playSound('click');
                }}
                className={`px-4 py-2 rounded-xl text-xs font-montserrat font-bold tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                  activeTab === tab
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white shadow-lg'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Responsive Preview Toggles */}
          <div className="hidden lg:flex items-center gap-1 px-2 py-1 rounded-xl bg-black/40 border border-white/10 text-xs font-mono text-slate-400">
            <span className="text-[11px] mr-1.5 text-slate-500">Preview:</span>
            <button
              onClick={() => setPreviewDevice('desktop')}
              className={`p-1.5 rounded-lg transition-colors ${previewDevice === 'desktop' ? 'bg-white/15 text-white' : 'hover:text-white'}`}
              title="Desktop View"
            >
              <Monitor size={15} />
            </button>
            <button
              onClick={() => setPreviewDevice('tablet')}
              className={`p-1.5 rounded-lg transition-colors ${previewDevice === 'tablet' ? 'bg-white/15 text-white' : 'hover:text-white'}`}
              title="Tablet View"
            >
              <Tablet size={15} />
            </button>
            <button
              onClick={() => setPreviewDevice('mobile')}
              className={`p-1.5 rounded-lg transition-colors ${previewDevice === 'mobile' ? 'bg-white/15 text-white' : 'hover:text-white'}`}
              title="Mobile View"
            >
              <Smartphone size={15} />
            </button>
          </div>
        </div>

        {/* Grid of 4: Portfolio Website, 3D Website, Business Website, App Development */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {filteredItems.map((item, idx) => {
            const Icon = item.icon;

            return (
              <div
                key={item.id}
                onClick={() => handleCardClick(item)}
                className="group relative rounded-3xl bg-[#12121A]/80 border border-white/10 hover:border-white/25 backdrop-blur-xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:scale-[1.01] cursor-pointer"
              >
                {/* Glow accent corner */}
                <div
                  className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-[70px] opacity-20 pointer-events-none group-hover:opacity-40 transition-opacity"
                  style={{ backgroundColor: item.accent }}
                />

                <div>
                  {/* Top Category Badge & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-2xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                        style={{
                          backgroundColor: `${item.accent}20`,
                          color: item.accent,
                          border: `1px solid ${item.accent}40`,
                        }}
                      >
                        <Icon size={24} />
                      </div>
                      <div>
                        <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                          Domain {idx + 1}
                        </span>
                        <h4 className="font-montserrat font-bold text-lg text-white">
                          {item.category}
                        </h4>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-xs font-mono text-slate-400 bg-white/5 px-3 py-1 rounded-full border border-white/5">
                      <span>Timeline: {item.estimatedDays}</span>
                    </div>
                  </div>

                  {/* Browser Mockup Frame with Image */}
                  <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#0A0A0F] mb-6 relative group-hover:border-white/30 transition-colors shadow-lg">
                    {/* Browser Chrome Header */}
                    <div className="px-3.5 py-2 bg-[#161622] border-b border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-red-500/70" />
                        <span className="w-2 h-2 rounded-full bg-yellow-500/70" />
                        <span className="w-2 h-2 rounded-full bg-green-500/70" />
                      </div>
                      <span className="text-[10px] font-mono text-slate-400 truncate max-w-[200px]">
                        https://ubaid.dev/showcase/{item.id}
                      </span>
                      <div className="w-10" />
                    </div>

                    {/* Image with zoom effect */}
                    <div className="aspect-video relative overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F]/80 via-transparent to-transparent pointer-events-none" />

                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                        <span className="text-xs font-montserrat font-semibold text-white bg-black/60 px-3 py-1 rounded-lg backdrop-blur-md border border-white/10">
                          {item.tagline}
                        </span>
                        <span
                          className="text-xs font-mono px-2.5 py-1 rounded-lg text-black font-bold flex items-center gap-1"
                          style={{ backgroundColor: item.accent }}
                        >
                          <span>Live Demo</span>
                          <ArrowUpRight size={12} />
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-slate-300 font-inter leading-relaxed mb-6">
                    {item.description}
                  </p>

                  {/* Key Deliverables Checkmarks */}
                  <div className="space-y-2 mb-6">
                    {item.deliverables.map((deliv, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-2.5 text-xs text-slate-300 font-inter">
                        <div
                          className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                          style={{ backgroundColor: `${item.accent}30`, color: item.accent }}
                        >
                          <Check size={11} strokeWidth={3} />
                        </div>
                        <span>{deliv}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer Tech Stack & Action */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="flex flex-wrap gap-1.5">
                    {item.techStack.map((tech, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-slate-400"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCardClick(item);
                    }}
                    className="text-xs font-montserrat font-bold text-white hover:text-[#00D4FF] flex items-center gap-1 cursor-pointer group-hover:translate-x-1 transition-transform"
                  >
                    <span>View Details</span>
                    <ArrowUpRight size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner CTA */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-r from-[#141422] via-[#1A1A2E] to-[#141422] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono text-[#00D4FF] mb-2">
              <Sparkles size={14} />
              <span>CUSTOM REQUESTS WELCOME</span>
            </div>
            <h3 className="font-montserrat font-extrabold text-2xl sm:text-3xl text-white">
              Need a custom blend of 3D, Web App & Business Landing?
            </h3>
            <p className="text-sm text-slate-400 font-inter mt-1 max-w-xl">
              I can build tailored multi-page, WebGL, or headless CMS platforms to match your exact vision.
            </p>
          </div>

          <button
            onClick={scrollToContact}
            className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] text-white font-montserrat font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_30px_rgba(0,212,255,0.4)] transition-all duration-300 hover:scale-[1.03] cursor-pointer whitespace-nowrap"
          >
            Start Your Website With Ubaid
          </button>
        </div>
      </div>
    </section>
  );
};
