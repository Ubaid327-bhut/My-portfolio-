import React from 'react';
import { Mail, MessageCircle, ArrowUp, Sparkles, Heart } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const Footer: React.FC = () => {
  const { email, whatsapp, playSound } = usePortfolio();

  const cleanPhone = whatsapp.replace(/\D/g, '');
  const waNumber = cleanPhone.startsWith('0') ? '92' + cleanPhone.slice(1) : cleanPhone;
  const whatsappUrl = `https://wa.me/${waNumber}`;

  const scrollToTop = () => {
    playSound('whoosh');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#08080C] border-t border-white/10 pt-16 pb-12 z-10 overflow-hidden">
      {/* Bottom glowing line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-[#7C3AED] to-transparent opacity-50" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center justify-between pb-12 border-b border-white/5">
          {/* Brand Info */}
          <div className="md:col-span-6 flex flex-col items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-2 mb-2">
              <span className="font-montserrat font-bold text-xl text-white tracking-wider">
                Ubaid
              </span>
              <span className="text-slate-400 font-mono text-sm">— Web Developer</span>
            </div>
            <p className="text-xs text-slate-400 font-inter max-w-md">
              Cinematic, full 3D interactive animation websites, business landing pages, modern portfolios, and custom web applications.
            </p>
          </div>

          {/* Direct Email & WhatsApp Contacts with Icons */}
          <div className="md:col-span-6 flex flex-wrap items-center justify-center md:justify-end gap-4">
            {/* Email Contact Pill with Email Icon */}
            <a
              href={`mailto:${email}`}
              onClick={() => playSound('click')}
              className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#12121A] hover:bg-[#1A1A26] border border-white/10 hover:border-[#00D4FF]/40 text-slate-200 hover:text-white transition-all text-xs font-mono group"
              title="Send direct email to Ubaid"
            >
              <div className="w-7 h-7 rounded-lg bg-[#00D4FF]/15 text-[#00D4FF] flex items-center justify-center group-hover:scale-110 transition-transform">
                <Mail size={15} />
              </div>
              <div className="text-left">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider">Email</div>
                <div className="font-semibold text-slate-200">{email}</div>
              </div>
            </a>

            {/* WhatsApp Contact Pill with WhatsApp Icon */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound('click')}
              className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#12121A] hover:bg-[#1A1A26] border border-white/10 hover:border-[#25D366]/40 text-slate-200 hover:text-white transition-all text-xs font-mono group"
              title="Chat on WhatsApp with Ubaid"
            >
              <div className="w-7 h-7 rounded-lg bg-[#25D366]/15 text-[#25D366] flex items-center justify-center group-hover:scale-110 transition-transform">
                <MessageCircle size={15} />
              </div>
              <div className="text-left">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider">WhatsApp</div>
                <div className="font-semibold text-slate-200">{whatsapp}</div>
              </div>
            </a>

            {/* Back to top */}
            <button
              onClick={scrollToTop}
              className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
              title="Scroll to Top"
              aria-label="Scroll to top"
            >
              <ArrowUp size={16} />
            </button>
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-inter text-slate-500">
          <div className="flex items-center gap-1.5">
            <span>© 2026 Ubaid. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
            <Sparkles size={12} className="text-[#7C3AED]" />
            <span>Built with React, Three.js, GSAP & Tailwind CSS</span>
          </div>

          <div className="flex items-center gap-1 text-[11px]">
            <span>Crafted with</span>
            <Heart size={11} className="text-[#00D4FF] fill-[#00D4FF]" />
            <span>for Web Excellence</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
