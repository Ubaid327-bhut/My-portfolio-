import React, { useState } from 'react';
import { Send, MessageCircle, Mail, Sparkles, Check, Copy, Settings, Clock, Shield } from 'lucide-react';
import confetti from 'canvas-confetti';
import { usePortfolio } from '../context/PortfolioContext';

export const ContactSection: React.FC = () => {
  const { email, whatsapp, setIsSettingsOpen, playSound } = usePortfolio();

  const [formData, setFormData] = useState({
    name: '',
    senderEmail: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  // Normalize WhatsApp number for wa.me URL
  // If Pakistani format 03338342392, convert to 923338342392 for international link
  const cleanPhone = whatsapp.replace(/\D/g, '');
  const waNumber = cleanPhone.startsWith('0') ? '92' + cleanPhone.slice(1) : cleanPhone;
  const whatsappUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    "Hi Ubaid, I saw your 3D portfolio and I have a website project idea to discuss with you!"
  )}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.senderEmail || !formData.message) return;

    setIsSubmitting(true);
    playSound('click');

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      playSound('success');

      // Trigger Confetti!
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#7C3AED', '#00D4FF', '#22C55E', '#FFFFFF'],
        });
      } catch {
        // Confetti fallback
      }

      // Also create mailto link for direct submission to user's configured email
      const subject = encodeURIComponent(`New Website Project Inquiry from ${formData.name}`);
      const body = encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.senderEmail}\n\nMessage:\n${formData.message}`
      );
      window.open(`mailto:${email}?subject=${subject}&body=${body}`, '_blank');
    }, 700);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(true);
    playSound('click');
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(whatsapp);
    setCopiedPhone(true);
    playSound('click');
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  return (
    <section id="contact" className="relative py-32 z-10 overflow-hidden bg-[#0A0A0F]">
      {/* Background ambient light */}
      <div className="absolute top-1/2 -right-20 w-96 h-96 bg-[#00D4FF]/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 -left-20 w-96 h-96 bg-[#7C3AED]/20 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Title: Contact With Me */}
        <div className="flex flex-col items-center text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#12121A] border border-white/10 text-xs font-mono text-[#00D4FF] mb-4">
            <Sparkles size={14} />
            <span>LET'S CONNECT</span>
          </div>

          <h2 className="font-bebas text-5xl sm:text-6xl md:text-8xl tracking-wide uppercase text-white mb-4">
            Contact <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#7C3AED] via-[#C084FC] to-[#00D4FF]">With Me</span>
          </h2>

          {/* EXACT TEXT REQUESTED: "Have any website or app idea? Contact me now." */}
          <p className="max-w-xl text-slate-300 font-inter text-lg sm:text-xl">
            Have any website or app idea?{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-[#00D4FF] font-semibold">
              Contact me now.
            </span>
          </p>

          <div className="w-24 h-1 bg-gradient-to-r from-[#7C3AED] to-[#00D4FF] rounded-full mt-4" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Direct WhatsApp Button & Direct Info Cards */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* WHATSAPP BIG GREEN BUTTON: "Chat on WhatsApp" */}
            <div className="p-8 rounded-3xl bg-gradient-to-br from-[#121E15] to-[#12121A] border border-[#25D366]/40 shadow-[0_0_40px_rgba(37,211,102,0.15)] relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#25D366]/20 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-2xl bg-[#25D366]/20 text-[#25D366] flex items-center justify-center">
                  <MessageCircle size={26} />
                </div>
                <div>
                  <span className="text-xs font-mono uppercase tracking-wider text-[#25D366] font-semibold">
                    Instant Chat • Quickest Reply
                  </span>
                  <h3 className="font-montserrat font-bold text-xl text-white">
                    Direct WhatsApp
                  </h3>
                </div>
              </div>

              <p className="text-sm text-slate-300 font-inter leading-relaxed mb-6">
                Prefer immediate messaging? Reach out directly to discuss your website or app requirements in real time.
              </p>

              {/* Big Green Button: Chat on WhatsApp */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('whoosh')}
                className="w-full py-4 px-6 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-black font-montserrat font-extrabold text-sm tracking-wider uppercase flex items-center justify-center gap-3 shadow-[0_0_25px_rgba(37,211,102,0.4)] transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
              >
                <MessageCircle size={22} className="fill-black" />
                <span>Chat on WhatsApp</span>
              </a>

              <div className="mt-4 flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Number: {whatsapp}</span>
                <button
                  onClick={handleCopyPhone}
                  className="text-slate-300 hover:text-[#25D366] flex items-center gap-1 transition-colors cursor-pointer"
                  title="Copy Phone Number"
                >
                  {copiedPhone ? <Check size={14} className="text-[#25D366]" /> : <Copy size={14} />}
                  <span>{copiedPhone ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Direct Email Card */}
            <div className="p-6 rounded-2xl bg-[#12121A]/80 border border-white/10 backdrop-blur-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#00D4FF]/20 text-[#00D4FF] flex items-center justify-center">
                    <Mail size={20} />
                  </div>
                  <div>
                    <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                      Send An Email
                    </span>
                    <h4 className="font-montserrat font-bold text-white text-sm">
                      {email}
                    </h4>
                  </div>
                </div>

                <button
                  onClick={handleCopyEmail}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  title="Copy Email Address"
                >
                  {copiedEmail ? <Check size={16} className="text-[#00D4FF]" /> : <Copy size={16} />}
                </button>
              </div>

              <p className="text-xs text-slate-400 font-inter">
                Emails are sent directly to Ubaid's inbox. Responses within 24 hours.
              </p>
            </div>

            {/* Availability Badges */}
            <div className="p-5 rounded-2xl bg-[#12121A]/50 border border-white/10 flex items-center justify-between text-xs text-slate-400 font-mono">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-[#7C3AED]" />
                <span>Response Time: &lt; 2 Hours</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield size={16} className="text-[#00D4FF]" />
                <span>100% Confidential</span>
              </div>
            </div>

            {/* Quick settings prompt */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs text-slate-400">
              <span>Need to change email or WhatsApp number?</span>
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="text-[#00D4FF] hover:underline flex items-center gap-1 font-semibold cursor-pointer"
              >
                <Settings size={13} />
                <span>Settings</span>
              </button>
            </div>
          </div>

          {/* Right Column: Email Form (Name, Email, Message, Submit) */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-3xl bg-[#12121A]/85 border border-white/10 backdrop-blur-xl relative shadow-2xl">
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10">
                <div>
                  <h3 className="font-montserrat font-extrabold text-2xl text-white">
                    Send a Message
                  </h3>
                  <p className="text-xs font-mono text-slate-400 mt-1">
                    Delivers straight to <span className="text-[#00D4FF]">{email}</span>
                  </p>
                </div>

                <div className="w-10 h-10 rounded-xl bg-[#7C3AED]/20 text-[#7C3AED] flex items-center justify-center">
                  <Send size={20} />
                </div>
              </div>

              {submitted ? (
                <div className="py-12 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4">
                    <Check size={32} />
                  </div>
                  <h4 className="font-montserrat font-bold text-2xl text-white mb-2">
                    Message Dispatched!
                  </h4>
                  <p className="text-sm text-slate-300 max-w-md font-inter mb-6">
                    Thank you! Your inquiry has been forwarded to Ubaid at{' '}
                    <span className="text-[#00D4FF] font-mono">{email}</span>. You will receive a response shortly.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({ name: '', senderEmail: '', message: '' });
                    }}
                    className="px-6 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-montserrat font-bold tracking-wider uppercase transition-colors"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name field */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-2">
                      Your Name <span className="text-[#00D4FF]">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Alex Morgan"
                      className="w-full px-4 py-3.5 rounded-xl bg-[#0A0A0F] border border-white/10 text-white placeholder-slate-600 focus:outline-none focus:border-[#7C3AED] focus:ring-1 focus:ring-[#7C3AED] transition-all text-sm font-inter"
                    />
                  </div>

                  {/* Email field */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-2">
                      Your Email <span className="text-[#00D4FF]">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.senderEmail}
                      onChange={(e) => setFormData({ ...formData, senderEmail: e.target.value })}
                      placeholder="alex@company.com"
                      className="w-full px-4 py-3.5 rounded-xl bg-[#0A0A0F] border border-white/10 text-white placeholder-slate-600 focus:outline-none focus:border-[#00D4FF] focus:ring-1 focus:ring-[#00D4FF] transition-all text-sm font-inter"
                    />
                  </div>

                  {/* Message field */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-slate-300 mb-2">
                      Project Details & Message <span className="text-[#00D4FF]">*</span>
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tell me about your website or app idea, desired timeline, and features..."
                      className="w-full px-4 py-3.5 rounded-xl bg-[#0A0A0F] border border-white/10 text-white placeholder-slate-600 focus:outline-none focus:border-[#7C3AED] focus:ring-1 focus:ring-[#7C3AED] transition-all text-sm font-inter resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-8 rounded-xl bg-gradient-to-r from-[#7C3AED] via-[#6322BE] to-[#00D4FF] text-white font-montserrat font-bold text-sm uppercase tracking-wider hover:shadow-[0_0_35px_rgba(124,58,237,0.5)] transition-all duration-300 hover:scale-[1.01] active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 group disabled:opacity-60"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                        <span>Sending Message...</span>
                      </span>
                    ) : (
                      <>
                        <span>Submit Project Inquiry</span>
                        <Send size={16} className="transition-transform group-hover:translate-x-1" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
