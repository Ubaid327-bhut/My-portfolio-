import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const ThreeCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 22;

    // Renderer with transparency
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Chrome Metallic Material
    const chromeMaterial = new THREE.MeshStandardMaterial({
      color: 0x222228,
      metalness: 0.95,
      roughness: 0.12,
      envMapIntensity: 1.5,
    });

    const wireframeAccent = new THREE.MeshBasicMaterial({
      color: 0x00D4FF,
      wireframe: true,
      transparent: true,
      opacity: 0.25,
    });

    const purpleGlowMaterial = new THREE.MeshStandardMaterial({
      color: 0x7C3AED,
      emissive: 0x7C3AED,
      emissiveIntensity: 0.6,
      metalness: 0.8,
      roughness: 0.2,
    });

    // 1. Center / Floating Large Chrome Torus Knot
    const knotGeometry = new THREE.TorusKnotGeometry(2.4, 0.7, 128, 32);
    const knotMesh = new THREE.Mesh(knotGeometry, chromeMaterial);
    knotMesh.position.set(4.5, 0.5, -2);
    scene.add(knotMesh);

    // 2. Secondary Floating Ring
    const ringGeometry = new THREE.TorusGeometry(3.5, 0.12, 16, 100);
    const ringMesh = new THREE.Mesh(ringGeometry, wireframeAccent);
    ringMesh.position.set(4.5, 0.5, -2);
    ringMesh.rotation.x = Math.PI / 3;
    scene.add(ringMesh);

    // 3. Floating Chrome Polyhedra in background
    const floatingObjects: { mesh: THREE.Mesh; rotSpeedX: number; rotSpeedY: number; floatSpeed: number; basePosY: number }[] = [];

    const shapes = [
      { geom: new THREE.IcosahedronGeometry(1.2, 0), pos: [-8, 4, -6], mat: chromeMaterial },
      { geom: new THREE.OctahedronGeometry(1.5, 0), pos: [-6, -5, -4], mat: purpleGlowMaterial },
      { geom: new THREE.TorusGeometry(1.8, 0.2, 16, 64), pos: [9, -6, -5], mat: chromeMaterial },
      { geom: new THREE.DodecahedronGeometry(0.9, 0), pos: [7, 7, -8], mat: chromeMaterial },
      { geom: new THREE.RingGeometry(1.2, 1.4, 32), pos: [-10, 0, -5], mat: wireframeAccent },
    ];

    shapes.forEach((s) => {
      const mesh = new THREE.Mesh(s.geom, s.mat);
      mesh.position.set(s.pos[0], s.pos[1], s.pos[2]);
      scene.add(mesh);
      floatingObjects.push({
        mesh,
        rotSpeedX: (Math.random() - 0.5) * 0.015,
        rotSpeedY: (Math.random() - 0.5) * 0.015,
        floatSpeed: 0.001 + Math.random() * 0.001,
        basePosY: s.pos[1],
      });
    });

    // 4. Subtle cyber dust particles
    const particleCount = 450;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    const purpleColor = new THREE.Color(0x7C3AED);
    const blueColor = new THREE.Color(0x00D4FF);

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 50;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 40;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 30 - 5;

      const mixedColor = Math.random() > 0.5 ? purpleColor : blueColor;
      particleColors[i * 3] = mixedColor.r;
      particleColors[i * 3 + 1] = mixedColor.g;
      particleColors[i * 3 + 2] = mixedColor.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 0.12,
      vertexColors: true,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // Lighting (Electric Purple & Neon Blue Rim Lights)
    const ambientLight = new THREE.AmbientLight(0x0A0A0F, 1.5);
    scene.add(ambientLight);

    // Electric Purple Point Light (Top-Right)
    const purpleLight = new THREE.PointLight(0x7C3AED, 60, 50);
    purpleLight.position.set(8, 8, 8);
    scene.add(purpleLight);

    // Neon Blue Point Light (Bottom-Left)
    const blueLight = new THREE.PointLight(0x00D4FF, 70, 50);
    blueLight.position.set(-8, -6, 6);
    scene.add(blueLight);

    // Subtle White Specular Key Light
    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(0, 10, 15);
    scene.add(keyLight);

    // Mouse & Scroll Interactivity
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    let scrollY = 0;
    let targetScrollY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      mouse.targetX = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.targetY = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    const handleScroll = () => {
      targetScrollY = window.scrollY;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    // Handle Window Resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smooth mouse interpolation
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Smooth scroll interpolation
      scrollY += (targetScrollY - scrollY) * 0.06;
      const scrollFactor = scrollY * 0.0025;

      // Torus Knot rotation + scroll reaction
      knotMesh.rotation.x = elapsed * 0.25 + scrollFactor * 1.2;
      knotMesh.rotation.y = elapsed * 0.35 + mouse.x * 0.8;
      knotMesh.position.y = 0.5 + Math.sin(elapsed * 1.2) * 0.3 - scrollFactor * 2;
      knotMesh.position.x = 4.5 + mouse.x * 1.2;

      ringMesh.rotation.x = Math.PI / 3 + elapsed * 0.15;
      ringMesh.rotation.z = elapsed * 0.2 + scrollFactor * 0.8;
      ringMesh.position.y = knotMesh.position.y;
      ringMesh.position.x = knotMesh.position.x;

      // Floating Shapes
      floatingObjects.forEach((obj, idx) => {
        obj.mesh.rotation.x += obj.rotSpeedX;
        obj.mesh.rotation.y += obj.rotSpeedY;
        obj.mesh.position.y = obj.basePosY + Math.sin(elapsed * 1.5 + idx) * 0.5 - scrollFactor * 1.5;
        obj.mesh.position.x += Math.cos(elapsed * 0.8 + idx) * 0.003;
      });

      // Slowly rotate particle field
      particles.rotation.y = elapsed * 0.02 + scrollFactor * 0.2;
      particles.rotation.x = mouse.y * 0.1;

      // Camera parallax based on mouse
      camera.position.x = mouse.x * 2.5;
      camera.position.y = mouse.y * 2 - scrollFactor * 1.2;
      camera.lookAt(0, -scrollFactor * 1.2, 0);

      // Light shifts
      purpleLight.position.x = 8 + Math.sin(elapsed) * 2 + mouse.x * 4;
      blueLight.position.y = -6 + Math.cos(elapsed) * 2 - mouse.y * 4;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      style={{ opacity: 0.9 }}
      aria-hidden="true"
    />
  );
};
