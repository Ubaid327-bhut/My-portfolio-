import React, { createContext, useContext, useState } from 'react';

interface PortfolioContextType {
  profilePic: string;
  setProfilePic: (url: string) => void;
  email: string;
  setEmail: (email: string) => void;
  whatsapp: string;
  setWhatsapp: (num: string) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  resetToDefaults: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  playSound: (type?: 'click' | 'whoosh' | 'success') => void;
}

const DEFAULT_PROFILE_PIC = '/images/ubaid-profile.jpg';
const DEFAULT_EMAIL = 'obaidabbasi767@gmail.com';
const DEFAULT_WHATSAPP = '03338342392';

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export const PortfolioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profilePic, setProfilePicState] = useState<string>(() => {
    return localStorage.getItem('ubaid_profile_pic') || DEFAULT_PROFILE_PIC;
  });

  const [email, setEmailState] = useState<string>(() => {
    return localStorage.getItem('ubaid_email') || DEFAULT_EMAIL;
  });

  const [whatsapp, setWhatsappState] = useState<string>(() => {
    return localStorage.getItem('ubaid_whatsapp') || DEFAULT_WHATSAPP;
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);

  const setProfilePic = (url: string) => {
    setProfilePicState(url);
    localStorage.setItem('ubaid_profile_pic', url);
  };

  const setEmail = (newEmail: string) => {
    setEmailState(newEmail);
    localStorage.setItem('ubaid_email', newEmail);
  };

  const setWhatsapp = (newNum: string) => {
    setWhatsappState(newNum);
    localStorage.setItem('ubaid_whatsapp', newNum);
  };

  const resetToDefaults = () => {
    setProfilePic(DEFAULT_PROFILE_PIC);
    setEmail(DEFAULT_EMAIL);
    setWhatsapp(DEFAULT_WHATSAPP);
  };

  // Synthetic Web Audio API sounds for subtle cybernetic feedback
  const playSound = (type: 'click' | 'whoosh' | 'success' = 'click') => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(400, audioCtx.currentTime + 0.05);
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.05);
      } else if (type === 'whoosh') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(200, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(600, audioCtx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.16); // G5
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.28);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.28);
      }
    } catch {
      // AudioContext not allowed or not supported
    }
  };

  return (
    <PortfolioContext.Provider
      value={{
        profilePic,
        setProfilePic,
        email,
        setEmail,
        whatsapp,
        setWhatsapp,
        isSettingsOpen,
        setIsSettingsOpen,
        resetToDefaults,
        soundEnabled,
        setSoundEnabled,
        playSound,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
};
